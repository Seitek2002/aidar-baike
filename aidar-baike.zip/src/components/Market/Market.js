import Tabs from "./Tabs/Tabs"


const Market = () => {
    return (
        <div className="market-main">

            <Tabs /> 
        </div>
    )
}

export default Market