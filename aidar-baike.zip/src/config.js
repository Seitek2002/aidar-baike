export const API_URL = 'https://bityx.com';
